Voice Operator Panel
--------------------

The application starts with a wizard which will help you configure it for the first time.

You can later review the Settings window of the application for all the available settings.

The application has an example of a user modifiable local directory with a "John Doe" user.

You can be modify it with your own users and phone numbers using the right-click menu.



Documentation
-------------

The documentation is available through the start menu shortcut or in the application folder "documentation":

VOP-user_interface.pdf - Description of the application user interface.

VOP-micro-user_interface.pdf - Description of the Micro edition user interface.

VOP-files.pdf - List of the application files and folders.

VOP-configuration.pdf - List of all the available configuration parameters.

VOP-operating_mode.pdf - Description of the different operating modes.

VOP-setup.pdf - Suggested setup for the application and its optional hard phone with a description of their interaction.

VOP-editions.pdf - Description of the Voice Operator Panel editions.

You can also review our FAQ online here: http://www.VoiceOperatorPanel.com/faq/



Requirements
------------

OS requirements:
Windows XP (or any later Windows OS)
AND .NET 2.0 framework installed (or 3.0 or 3.5)



Website
-------

http://www.VoiceOperatorPanel.com/
